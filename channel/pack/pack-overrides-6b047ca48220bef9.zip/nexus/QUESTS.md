# Campagne Nexus Vanilla+ Remastered

La campagne contient 395 quêtes réparties dans 18 chapitres. Les objectifs ont
été vérifiés contre les objets et entités réellement présents dans le pack.

## Progression

1. Survie, nature et premiers outils.
2. Exploration des structures Vanilla et YUNG.
3. Économie, cuisine et construction.
4. Create : énergie, machines, trains, transport et Aeronautics.
5. Combat : Punchy, Ziplines, Throwable, créatures et dragons Ice and Fire.
6. Tempad et maîtrise du temps.
7. Nether, End, compagnons, coopération et défis secrets.
8. Finale du Nexus puis ouverture de la branche Mekanism Basic.

La technologie Mekanism est bloquée avant la récompense « Maître du Temps ».
Cette récompense lance la commande serveur qui ouvre la branche technologique.
Le pack ne présente pas cette technologie comme un départ de progression.

## Récompenses

Les récompenses privilégient la monnaie, les ressources et les composants utiles.
Les machines complètes, équipements ultimes, dragons et objets Tempad puissants
ne sont pas distribués gratuitement. La progression reste une survie à accomplir.

Les fichiers de campagne sont dans `config/ftbquests/quests`. Ils sont aussi
embarqués dans le launcher et dans le fichier `.mrpack` officiel Nexus.

