# Économie Nexus Vanilla+

La monnaie est entièrement numérique et s'affiche en N$. Le solde est conservé
par le serveur : aucun portefeuille ni bloc de banque n'est nécessaire.

## Commandes des joueurs

- `/shop` : ouvrir la boutique officielle. Clic gauche pour un lot, clic droit
  pour quatre lots.
- `/sell hand` : vendre la pile tenue si elle est rachetée par le serveur.
- `/sell all` : afficher la valeur des ressources éligibles, puis confirmer en
  retapant la commande dans les 15 secondes.
- `/argent` : consulter son solde.
- `/idcommerce` : afficher son identifiant de paiement.
- `/payer <identifiant> <montant>` : payer directement un autre joueur.
- `/vendre <prix>` : créer un présentoir de vente entre joueurs avec la pile
  tenue en main.
- `/retirerboutique` : récupérer son présentoir proche.
- `/aidecommerce` : afficher l'aide de l'économie.
- `/menu` : ouvrir le menu général du Nexus.

Les objets renommés, enchantés, endommagés ou possédant des données spéciales ne
sont jamais pris par `/sell`. Le plafond de solde est de 2 000 000 000 N$.

## Boutique officielle

Elle ne vend aucune machine Create, aucun artefact, aucun dragon et aucun objet
Tempad. Les récompenses puissantes servent d'objectifs de très longue durée.

| Objet | Quantité | Prix |
|---|---:|---:|
| Torches | 64 | 500 N$ |
| Pain | 64 | 500 N$ |
| Bûches de chêne | 32 | 1 000 N$ |
| Charbon | 32 | 2 000 N$ |
| Fer | 16 | 5 000 N$ |
| Étiquette | 1 | 20 000 N$ |
| Selle | 1 | 30 000 N$ |
| Boules de slime | 16 | 50 000 N$ |
| Totem d'immortalité | 1 | 50 000 000 N$ |
| Armure complète en diamant | 1 ensemble | 100 000 000 N$ |
| Armure complète en netherite | 1 ensemble | 500 000 000 N$ |

Le fichier `config/nexus/shop.json` permet à l'administrateur de modifier les
achats et les prix de rachat sans recompiler Nexus Core. Après modification,
utiliser `/nexus reload-shop` depuis la console ou avec le niveau opérateur 4.

