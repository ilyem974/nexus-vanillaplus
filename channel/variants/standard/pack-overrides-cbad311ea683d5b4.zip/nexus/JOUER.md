# Jouer sur Nexus Vanilla+ Remastered

## Avec le launcher Nexus

1. Ouvrir `NexusLauncher.exe`.
2. Choisir 4, 6, 8 ou 10 Go de mémoire et le profil graphique souhaité.
3. Cliquer sur **Jouer**. Le launcher télécharge, vérifie et répare le pack.
4. Au premier lancement, ajouter son compte Microsoft dans la fenêtre officielle
   Prism Launcher, la fermer, puis recliquer sur **Jouer**.

Le launcher installe Java 21, ajoute le serveur
`irvine-upfront.tun.ply.gg`, active les textures de dragons et d'armures,
configure les touches manquantes et conserve les fichiers déjà valides lors
d'une réparation. Les shaders sont désactivés par défaut ; les deux profils
shader les activent volontairement.

## Solution officielle de secours

Importer `Nexus-VanillaPlus-0.5.2.mrpack` dans Prism Launcher. Cette solution
installe le même manifeste et permet de jouer même si Windows refuse le launcher
Nexus non signé.

## Monde cinématique et dragons

- Le profil **Shaders** active Photon pour obtenir le rendu cinématique. Il reste
  optionnel pour préserver les FPS sur les petits PC.
- Terralith et Tectonic façonnent les grands reliefs. Les nouvelles variantes et
  les petits bonus de minerais apparaissent uniquement dans les chunks encore
  inexplorés ; la carte et les constructions existantes ne sont pas effacées.
- Dragon Mounts Remastered permet de trouver des œufs, les faire éclore,
  apprivoiser, élever et monter plusieurs races de dragons.

Ne désactive pas SmartScreen, Microsoft Defender ou le pare-feu pour lancer le
programme. Un avertissement de réputation ne peut être supprimé proprement que
par une signature Authenticode reconnue.

## Commandes utiles en jeu

- `/shop`, `/sell`, `/sell hand`, `/sell all`
- `/market`, `/market sell <prix>`
- `/piece deposer`, `/piece retirer <nombre>`
- `/rtp`
- `/tpa <joueur>`, `/tpaccept`, `/tpdeny`
- `/argent`, `/payer <identifiant> <montant>`
- `/vendre <prix>`, `/retirerboutique`
