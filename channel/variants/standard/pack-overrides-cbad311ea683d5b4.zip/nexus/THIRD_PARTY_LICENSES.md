# Nexus Vanilla+ — composants tiers

Dernière mise à jour : 23 août 2026.

## Politique de distribution

Nexus Launcher ne réhéberge pas automatiquement les JAR de mods. Le manifeste
`launcher/NexusLauncher/Resources/pack-manifest.json` référence leurs fichiers
officiels Modrinth ou CurseForge et vérifie chaque téléchargement avec SHA-512.
Les droits de chaque mod restent ceux indiqués par son auteur sur sa page de
projet. `Nexus Core`, les configurations Nexus et les quêtes sont les seuls
éléments propres au projet intégrés directement dans les overrides.

## Textures de dragons — True Dovah

- Auteur : ApprenticeNecromancer.
- Projet : https://modrinth.com/resourcepack/true-dovah
- Version intégrée : 1.0, fichier `True Dovah.zip`, annoncé compatible 1.21.1
  et Ice and Fire Community Edition.
- Licence annoncée : All Rights Reserved.
- Mode d'intégration : téléchargement direct depuis le CDN Modrinth officiel ;
  le ZIP n'est pas copié dans les overrides ni réhébergé par Nexus.
- Périmètre vérifié : toutes les ressources sont sous `assets/iceandfire/` ; le
  pack ne modifie aucun bloc, mob, ciel ou GUI Vanilla/Create.
- SHA-512 :
  `fa5e8cbcc5be8545884407ee36be200934230bc843f7231cef65ed6b7b445648f890a9890d00840c69940827ff9747fe3622a0827de6516cc5b71da30bf2ae09`.

## Graphismes optionnels et armures

- Better Armors : https://modrinth.com/resourcepack/better-armors — CC-BY-NC-4.0.
- MakeUp Ultra Fast : https://modrinth.com/shader/makeup-ultra-fast-shaders — LGPL-3.0.
- Photon : https://modrinth.com/shader/photon-shader — licence déclarée sur la page Modrinth.
- Les deux shaders sont téléchargés mais désactivés par défaut. Le launcher ne
  les active que lorsque le joueur choisit le profil correspondant.
- Better Armors est téléchargé depuis le CDN Modrinth et activé dans tous les
  profils du launcher.

## Extension Create, animations et optimisations 0.5.0

Les nouveaux JAR sont téléchargés depuis leurs fichiers Modrinth officiels et
contrôlés par SHA-512 dans le manifeste : Create: Missiles (GPL-3.0), Create:
Nuclear (LGPL-3.0), ParCool et son addon de compatibilité (LGPL-3.0), Patchouli,
Random Optimization, Redirected, TxniLib, SeamlessChunks, Flerovium, Sodium
Extra, Reese's Sodium Options, Vanillin, Mem Leak Fix GPU, LightSpeedRe, Cull
Particles et Fast IP Ping. Les licences et URL exactes restent attachées aux
pages de projets et aux entrées versionnées du manifeste.

## Dragons et minerais 0.5.2

- Dragon Mounts Remastered : https://www.curseforge.com/minecraft/mc-mods/dmr
  — version 1.9.2 pour NeoForge 1.21.1, fichier CurseForge 6974554, licence
  PolyForm Noncommercial 1.0.0. Le JAR reste téléchargé depuis le CDN officiel
  et est vérifié par SHA-512
  `90bd999d0378d24312a13bc0f44c45f9d756c5637684ddde688f0ba5ee5724f654eca11c19098c0b61b83374b88f9804283d10a3a38a5e36bfc91540f6b5c079`.
- Seamless Ores : https://www.curseforge.com/minecraft/mc-mods/seamless-ores
  — version 3.0.0 pour NeoForge 1.21.1, fichier CurseForge 8653342, licence
  PolyForm Shield 1.0.0. Le JAR reste téléchargé depuis le CDN officiel et est
  vérifié par SHA-512
  `084aeca5182f3248cadac1b7cdf7423dbbd7ad68f18b3dbbf8e5d4b35a389a43152b6273d6aaac149d069857890d78b27e66f7855b37c827771d6ef725f7a962`.
- Saint's Dragons n'est pas distribué dans Nexus : sa version officielle cible
  Minecraft 1.20.1 et n'est pas compatible avec NeoForge 1.21.1. Dragon Mounts
  Remastered fournit donc les œufs, l'éclosion, l'apprivoisement et les dragons
  montables sans casser le pack.

## Ice and Fire Community Edition

- Auteurs/crédits du JAR : IAFEnvoy, xiaowu, uoay et Alexthe666.
- Version : 2.1.1 pour Minecraft 1.21.1.
- Licence déclarée dans `META-INF/neoforge.mods.toml` : LGPL-3.0.
- Source : https://github.com/IAFEnvoy/IceAndFire-CE

## Constructions du spawn

Les crédits complets, autorisations et modifications sont conservés dans
`docs/SPAWN-CREDITS.md`.

- Medieval Townhouse Pack — 10 Houses + 4 Assets, Itzz_Aspect/Blo0ns & Aspect :
  https://www.planetminecraft.com/project/medieval-townhouse-pack-10-houses-4-assets-free-download/
- Small Medieval City Hall, eMek93/OffBeat/eMCraft :
  https://www.planetminecraft.com/project/small-medieval-city-hall/

Les pages des auteurs autorisent l'utilisation, la modification et l'usage sur
serveur. Les builds ont été convertis en structures Minecraft 1.21.1 puis
intégrés à un terrain, une place, des routes et des zones Nexus originales.

## Prism Launcher

- Projet : https://prismlauncher.org/
- Version embarquée : 11.0.3 portable.
- Licence : GPL-3.0-only.
- Nexus Launcher lance Prism pour l'authentification Microsoft officielle et ne
  lit ni mot de passe ni jeton de session.

## Eclipse Temurin / OpenJDK

- Projet : https://adoptium.net/temurin/
- Runtime : Temurin JDK 21.0.12+8 x64.
- Licence : GPLv2 avec Classpath Exception et licences tierces incluses dans le
  runtime officiel.
- Téléchargement HTTPS et SHA-256 vérifié avant extraction.

## Visuel du launcher

Le fond `launcher/NexusLauncher/Resources/nexus-remastered-hero.png` a été créé
spécifiquement pour Nexus avec ImageGen. Il ne contient ni logo tiers, ni texte,
ni copie d'une interface ou d'un build téléchargé.

## Liste exhaustive des téléchargements

La liste versionnée et vérifiable des fichiers distribués se trouve dans
`launcher/NexusLauncher/Resources/pack-manifest.json`. Pour chaque entrée : nom,
source officielle, URL, taille et SHA-512 sont conservés.
