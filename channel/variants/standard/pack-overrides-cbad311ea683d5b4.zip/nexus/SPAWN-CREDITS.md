# Spawn Nexus Vanilla+ Remastered

Le spawn combine une implantation originale Nexus (plateau, routes, pavillons, signalétique et zones fonctionnelles) avec deux packs de constructions utilisés conformément aux permissions affichées par leurs auteurs.

## Constructions utilisées

- **Medieval Townhouse Pack — 10 Houses + 4 Assets**, par Itzz_Aspect / Blo0ns & Aspect. Utilisation et adaptation autorisées sur un serveur public ou privé ; aucune redistribution séparée ni revente du fichier source. Source : https://www.planetminecraft.com/project/medieval-townhouse-pack-10-houses-4-assets-free-download/
- **Small Medieval City Hall**, par eMek93 / OffBeat / eMCraft. Partage, modification et utilisation sur serveur autorisés par l'auteur. Source : https://www.planetminecraft.com/project/small-medieval-city-hall/

Les fichiers sources restent dans `work/spawn-assets/source` pour la traçabilité. Ils ne doivent pas être publiés séparément du serveur Nexus.

## Implantation Nexus

- Centre : point d'arrivée et commandes essentielles.
- Nord : hôtel de ville et informations.
- Ouest : shop physique et exposition Create.
- Est : quêtes et récompenses.
- Sud : quartier médiéval puis sortie vers la survie.
- Protection : rayon de 160 blocs géré par Nexus Core.
