// Nexus Vanilla+ 0.6.0 — réservé aux enregistrements exécutés au démarrage.
