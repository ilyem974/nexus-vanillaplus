// Nexus Vanilla+ 0.6.0 — réservé aux recettes et événements serveur du pack.
